<?php
if (isset($_POST['jmeno']) && isset($_POST['heslo'])){
    $jmeno = $_POST['jmeno'];
    $heslo = $_POST['heslo'];
    if ($jmeno == "admin" && $heslo == "admin") {
        $_SESSION['login'] = 1;
    }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="navbar navbar-dark text-white bg-dark">
        <ul class="nav nav-pills">
        <li><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-arrow-through-heart-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M2.854 15.854A.5.5 0 0 1 2 15.5V14H.5a.5.5 0 0 1-.354-.854l1.5-1.5A.5.5 0 0 1 2 11.5h1.793l3.103-3.104a.5.5 0 1 1 .708.708L4.5 12.207V14a.5.5 0 0 1-.146.354l-1.5 1.5ZM16 3.5a.5.5 0 0 1-.854.354L14 2.707l-1.006 1.006c.236.248.44.531.6.845.562 1.096.585 2.517-.213 4.092-.793 1.563-2.395 3.288-5.105 5.08L8 13.912l-.276-.182A23.825 23.825 0 0 1 5.8 12.323L8.31 9.81a1.5 1.5 0 0 0-2.122-2.122L3.657 10.22a8.827 8.827 0 0 1-1.039-1.57c-.798-1.576-.775-2.997-.213-4.093C3.426 2.565 6.18 1.809 8 3.233c1.25-.98 2.944-.928 4.212-.152L13.292 2 12.147.854A.5.5 0 0 1 12.5 0h3a.5.5 0 0 1 .5.5v3Z"/>
</svg></li>
        <li><h3>Logo</h3></li>
            <li class="nav-item">
                <a class="nav-link" href="#">Home</a>
             </li>
            <li class="nav-item">
                <a class="nav-link" href="#">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Products</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Services</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Link 1</a></li>
                        <li><a class="dropdown-item" href="#">Link 2</a></li>
                        <li><a class="dropdown-item" href="#">Link 3</a></li>
                    </ul>
            </li>
        </ul>
        
        <?php
        if(isset($_SESSION['login']) && $_SESSION['login']==1){
            echo "<h2 style='margin:0;padding:0;'>Vítej ADMINE!!!</h2>";
            echo "<a href='logout.php'> Odhlásit </a><br><br>";
        }
        else{
            ?>
                <form action ="index.php" method="post">
                    Jméno<input type="text" name="jmeno"><br>
                    Heslo<input type="password" name="heslo"><br>
                    <input type="submit" value="odeslat">
                </form>
            
        <?php
        }
        ?>
        </div>
        </div>
    </div>
    <div class="container-fluid">
  <div class="jumbotron bg-warning text-success">
    <h1>Dramatically Engage</h1>      
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat..</p> 
    <input type="submit" value="Engage Now">  
</div>
<h1>Superior Colaboration <small style="color:grey">Visualise Quality</small></h1>
<hr>
<small style="color:grey">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis, quasi quis voluptatem accusantium placeat obcaecati eos omnis hic quidem quod? Consequuntur atque sequi adipisci fuga commodi iste deleniti dolores odit!</small>
<?php
        if(isset($_SESSION['login']) && $_SESSION['login']==1){
        ?>
        <div class="row">
          <div class="col-md-4">
            <div class="card mb-2">
              <img class="card-img-top" src="fotka.jpg">
              <div class="card-body">
                <h4 class="card-title">Efficiently Unleashed</h4>
                <p class="card-text">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolorum ut, voluptate deleniti qui ad unde doloribus ab velit, eveniet, eligendi perferendis numquam voluptates quod a itaque adipisci facilis nulla mollitia..</p>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card mb-2">
              <img class="card-img-top" src="fotka.jpg">
              <div class="card-body">
                <h4 class="card-title">Completely Synergize</h4>
                <p class="card-text">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolorum ut, voluptate deleniti qui ad unde doloribus ab velit, eveniet, eligendi perferendis numquam voluptates quod a itaque adipisci facilis nulla mollitia..</p>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card mb-2">
              <img class="card-img-top" src="fotka.jpg">
              <div class="card-body">
                <h4 class="card-title">Dynamically Procrastinate</h4>
                <p class="card-text">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolorum ut, voluptate deleniti qui ad unde doloribus ab velit, eveniet, eligendi perferendis numquam voluptates quod a itaque adipisci facilis nulla mollitia..</p>
              </div>
            </div>
          </div>
        </div>
        <?php
            }
        ?>
<div class="jumbotron bg-warning text-dark">
    <div class="row">
            <div class="col-md-4">
                <h3><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-boombox" viewBox="0 0 16 16">
                <path d="M2.5 5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1Zm2 0a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1Zm7.5-.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Zm1.5.5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1Zm-7-1a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3Zm5.5 6.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z"/>
                <path d="M11.5 13a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Zm0-1a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3ZM5 10.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z"/>
                <path d="M7 10.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Zm-1 0a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0Z"/>
                <path d="M14 0a.5.5 0 0 1 .5.5V2h.5a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1h12.5V.5A.5.5 0 0 1 14 0ZM1 3v3h14V3H1Zm14 4H1v7h14V7Z"/>
                </svg>Dynamically Procrastinate</h3>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Alias quae accusamus deleniti provident, unde fugiat impedit esse ad, debitis vel a in numquam quas optio beatae non possimus nihil vitae?</p>
                <input type="submit" value="Procrastinate">
            </div>

            <div class="col-md-4">
                    <h3><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-box" viewBox="0 0 16 16">
                    <path d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5 8 5.961 14.154 3.5 8.186 1.113zM15 4.239l-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923l6.5 2.6zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464L7.443.184z"/>
                    </svg>Efficiently Unleashed</h3>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Alias quae accusamus deleniti provident, unde fugiat impedit esse ad, debitis vel a in numquam quas optio beatae non possimus nihil vitae?</p>
                <input type="submit" value="Unleash">
            </div>

            <div class="col-md-4">
                <h3><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-briefcase-fill" viewBox="0 0 16 16">
                <path d="M6.5 1A1.5 1.5 0 0 0 5 2.5V3H1.5A1.5 1.5 0 0 0 0 4.5v1.384l7.614 2.03a1.5 1.5 0 0 0 .772 0L16 5.884V4.5A1.5 1.5 0 0 0 14.5 3H11v-.5A1.5 1.5 0 0 0 9.5 1h-3zm0 1h3a.5.5 0 0 1 .5.5V3H6v-.5a.5.5 0 0 1 .5-.5z"/>
                <path d="M0 12.5A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5V6.85L8.129 8.947a.5.5 0 0 1-.258 0L0 6.85v5.65z"/>
                </svg>Completely Synergize</h3>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Alias quae accusamus deleniti provident, unde fugiat impedit esse ad, debitis vel a in numquam quas optio beatae non possimus nihil vitae?</p>
                <input type="submit" value="Synergize">
            </div>
        </div>
</div>


</div>
</div>
        
       
        
    
        
</body>
</html>